* * WynnEdits - Dark Theme for MC 1.21 * *
      By SpektrSoyuz

	- WynnEdits - Dark Theme is a reskin of the Wynncraft UI with an overall darker and more Dernic-inspired palette.


* * Release v1.7 * *

	Changes
		- Dark Theme is now compatible with the August 20th Wynncraft Resource Pack.