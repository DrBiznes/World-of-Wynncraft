* * WynnEdits - Dark Theme for MC 1.21 * *
      By SpektrSoyuz

	- WynnEdits - Dark Theme is a reskin of the Wynncraft UI with an overall darker and more Dernic-inspired palette.


* * Release v1.10 * *

	Changes
		- Dark-ified the Wynntils Player List overlay
		- Fixed Esc. Menu overlay